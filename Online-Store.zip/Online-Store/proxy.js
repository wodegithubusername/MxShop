module.exports = {
  "/": "http://shop.projectsedu.com:8001"
};
