module.exports = [
          {
            url:'/',
            img:'http://sx.youxueshop.com/data/afficheimg/20151201umhbbv.jpg',
            id:'1'
          },
          {
            url:'/',
            img:'http://sx.youxueshop.com/data/afficheimg/20151201euxrsd.jpg',
            id:'2'
          },
          {
            url:'/',
            img:'http://sx.youxueshop.com/data/afficheimg/20151201zbegze.jpg',
            id:'3'
          }
        ]



